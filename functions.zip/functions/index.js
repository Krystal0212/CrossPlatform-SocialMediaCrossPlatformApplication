const functions = require("firebase-functions");
const nodemailer = require("nodemailer");
const express = require('express');
const cors = require('cors');
const fs = require('fs');
const path = require('path');
const admin = require('firebase-admin');
const crypto = require('crypto');

const app = express();
//const key = crypto.randomBytes(32); // AES-256 requires a 32-byte key
//const iv = crypto.randomBytes(16);  // AES uses a 16-byte IV
const key = Buffer.from('e2c1a97d384b6f6b8f6e92d3f51f4e05'); // Example 32-byte AES key
const iv = Buffer.from('a3f8d1a6d8e2f7b4');

admin.initializeApp();

app.use(cors({
   origin: '*',
   methods: ['GET', 'POST'],
   allowedHeaders: 'X-Requested-With, Content-Type, auth-token',
}));

function encrypt(text) {
   const cipher = crypto.createCipheriv('aes-256-cbc', key, iv);
   let encrypted = cipher.update(text, 'utf8', 'hex');
   encrypted += cipher.final('hex');
   // Include the IV with the encrypted result (e.g., prepend or append)
   return `${iv.toString('hex')}:${encrypted}`;
}

function decrypt(text) {
   const parts = text.split(':');
   if (parts.length < 2) {
      throw new Error("Invalid encrypted text format");
   }
   const iv = Buffer.from(parts.shift(), 'hex'); // Extract IV
   const encryptedText = parts.join(':'); // Extract encrypted text
   const decipher = crypto.createDecipheriv('aes-256-cbc', key, iv);
   let decrypted = decipher.update(encryptedText, 'hex', 'utf8');
   decrypted += decipher.final('utf8');
   return decrypted;
}

// Configure Nodemailer transporter
const transporter = nodemailer.createTransport({
   host: "smtp-relay.sendinblue.com",
   port: 587,
   secure: false, // Use TLS
   auth: {
      user: '821738001@smtp-brevo.com',
      pass: 'xsmtpsib-e7750de3e40e6f370481783ee9f5fe820778209227a74bd46575eff463c3ebcc-OqNSt6EyfdDH9ghj',
   },
});

const minuteToExpire = 10;

// Cloud Function to send an email
app.post('/sendEmailWithOTP', async (req, res) => {
   let {
      recipientEmail,
      otpCode,
      verificationLink
   } = req.body;

   let timestamp = admin.firestore.FieldValue.serverTimestamp();
   let userIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
   const sessionId = crypto.randomUUID().toString();
   const encryptedOTP = encrypt(otpCode);

   try {
      let additionParameters = 'otp=' + otpCode + '&timestamp=' + timestamp + '&sessionId=' + sessionId;
      additionParameters = encrypt(additionParameters);
      let finalVerificationLink = verificationLink + additionParameters;

      const otpDocRef = admin.firestore().collection('otp').doc(recipientEmail);

      const docSnapshot = await otpDocRef.get();

      if (docSnapshot.exists) {
        // If the document exists, delete it
        await otpDocRef.delete();
      }

      // Save OTP in Firestore with expiration time (valid for 5 minutes)
      await admin.firestore().collection('otp').doc(recipientEmail).set({
         otp: encryptedOTP,
         sessionId: sessionId,
         ip: userIP,
         createdAt: timestamp,
      });

      // Load the HTML template and replace placeholders
      const templatePath = path.join(__dirname, 'email-template.html');
      const html = fs.readFileSync(templatePath, 'utf8');
      const htmlWithOtp = html.replace('{OTP_CODE}', otpCode)
         .replace('{verification_link}', finalVerificationLink)
         .replace('{minute}', minuteToExpire);

      // Prepare email data
      const mailOptions = {
         from: 'support@zineround.site',
         to: recipientEmail,
         subject: 'Unlock Your Account - Verify Now!',
         html: htmlWithOtp,
      };

      // Send the email
      await transporter.sendMail(mailOptions);

      res.status(200).send('The email has been sent to user' + finalVerificationLink);
   } catch (error) {
      console.error(error);
      res.status(500).send(error.message);
   }
});

app.post('/sendEmailResetPassword', async (req, res) => {
   //Define function parameter
   let {
      recipientEmail,
      otpCode,
   } = req.body;

   // Handle null params

   // Deploy logic to send email without verification link. only otp for reset email
});

app.get('/verifyOTPByLink', async (req, res) => {
   try {
      // Get the encrypted verification link from the query parameters
      const {
         encryptedLink
      } = req.query;

      if (!encryptedLink) {
         return res.status(400).send('Invalid or missing verification link.');
      }

      const decryptedLink = decrypt(encryptedLink);

      const url = new URL('https://dummy.com?' + decryptedLink);
      const otp = url.searchParams.get('otp');
      const timestamp = url.searchParams.get('timestamp');
      const sessionId = url.searchParams.get('sessionId');

      // Validate the OTP and session information
      const otpDocQuery = await admin.firestore().collection('otp')
         .where('sessionId', '==', sessionId);

      const otpDocSnapshot = await otpDocQuery.get(); // Execute the query to get the documents

      if (otpDocSnapshot.empty) {
         return res.status(400).send('No matching record found.');
      }


      const otpDoc = otpDocSnapshot.docs[0]; // Access the first document's data

      const {
         otp: storedOtp,
         sessionId: storedSessionId,
         ip,
         createdAt
      } = otpDoc.data();
      const expirationTime = new Date(createdAt).getTime() + minuteToExpire * 60 * 1000;
      let decryptedOTP = decrypt(storedOtp)

      if (Date.now() > expirationTime || otp !== decrypt(storedOtp)) {
         return res.status(400).send('Invalid or expired. otp' + otp + 'stored Otp' + decryptedOTP);
      }

      //Check the IP address
      const userIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
      if (userIP !== ip) {
         return res.status(403).send('IP address mismatch.');
      }

      const userEmail = otpDoc.id;

      try {
         const userRecord = await admin.auth().getUserByEmail(userEmail);
         await admin.auth().updateUser(userRecord.uid, {
            emailVerified: true,
         });
      } catch (error) {
         console.error('Error fetching user data:', error);
         res.status(406).send('Can not found user data');
      }

      // If all checks pass, consider the OTP verified
      res.status(200).send('OTP verified successfully.');
      await otpDoc.ref.delete();
   } catch (error) {
      console.error('Error during OTP verification:', error);
      res.status(500).send('An error occurred while verifying the OTP.');
   }
});

app.get('/verifyOTPByCode', async (req, res) => {
   const {
      otpCode, userLoggedEmail
   } = req.query;

   if (!otpCode || !userLoggedEmail || otpCode.trim() === '' || userLoggedEmail.trim() === '') {
      return res.status(400).send('Invalid or missing OTP code and user email.');
   }

   try {
      // Validate the OTP and session information
      const otpDocQuery = await admin.firestore().collection('otp').doc(userLoggedEmail);
      const otpDoc = await otpDocQuery.get();

      if (otpDoc.empty) {
         return res.status(400).send('No matching record found.');
      }

      const {
         otp: storedOtp,
         sessionId: storedSessionId,
         ip,
         createdAt
      } = otpDoc.data();
      const expirationTime = new Date(createdAt).getTime() + minuteToExpire * 60 * 1000;

      if (Date.now() > expirationTime - 10000) {
         return res.status(400).send('OTP has expired.');
      }

      if (otpCode !== decrypt(storedOtp)) {
         return res.status(400).send('Invalid OTP.');
      }

      // Check the IP address
      const userIP = req.headers['x-forwarded-for'] || req.connection.remoteAddress;
      if (userIP !== ip) {
         return res.status(403).send('IP address mismatch.');
      }

      try {
         const userRecord = await admin.auth().getUserByEmail(userLoggedEmail);
         await admin.auth().updateUser(userRecord.uid, {
            emailVerified: true,
         });
      } catch (error) {
         console.error('Error fetching user data:', error);
         res.status(406).send('Can not found user data');
      }

      // If all checks pass, consider the OTP verified
      res.status(200).send('OTP verified successfully.');
      await otpDoc.ref.delete();
   } catch (error) {
      console.error('Error during OTP verification:', error);
      res.status(500).send('An error occurred while verifying the OTP :' + error);
   }
});

exports.api = functions.https.onRequest(app);